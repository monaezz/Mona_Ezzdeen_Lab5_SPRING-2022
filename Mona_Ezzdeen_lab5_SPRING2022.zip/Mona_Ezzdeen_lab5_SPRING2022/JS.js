

function set() {
    var y = document.getElementById("rectangle");
    y.style.width = document.getElementById('w').value + "px";
    y.style.height = document.getElementById('h').value + "px";

}
function ChangeColor(color) {
    var x = document.getElementById("rectangle");
    x.style.backgroundColor = color;
}
function ChangeBorder(style) {

    var x = document.getElementById("rectangle");
    x.style.borderStyle = style;


}

function Color(style) {

    var x = document.getElementById("rectangle");
    x.style.borderColor = style;
}


function bordersize() {
    var x = document.getElementById("rectangle");
    x.style.borderWidth = document.getElementById('size').value + "px";

}
